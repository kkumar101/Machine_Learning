# -*- coding: utf-8 -*-
"""
Created on Thu Mar 16 02:48:16 2023

@author: Yujoon Jang
"""

import csv
import random
import pandas as pd
from collections import defaultdict

filepath = 'G:/내 드라이브/Fordham/Madness/'
sheetname = 'Result'

def read_bracket(file_name):
    bracket_df = pd.read_csv(file_name)
    games = {}
    for region in bracket_df['region'].unique():
        region_games = []
        for i in range(1, 17, 2):
            team1_id = bracket_df.loc[(bracket_df['region'] == region) & (bracket_df['number'] == i), 'team_id'].iloc[0]
            team2_id = bracket_df.loc[(bracket_df['region'] == region) & (bracket_df['number'] == i + 1), 'team_id'].iloc[0]
            region_games.append((team1_id, team2_id))
        games[region] = region_games
    return games

def get_team_name_mapping(bracket_file):
    bracket_df = pd.read_csv(bracket_file)
    team_name_mapping = {}
    for _, row in bracket_df.iterrows():
        team_id = row['team_id']
        team_name = row['data_teamname']
        team_name_mapping[team_id] = team_name
    return team_name_mapping

def read_probabilities(file_name):
    probabilities_df = pd.read_excel(file_name, sheet_name=sheetname)
    probabilities = {}
    for _, row in probabilities_df.iterrows():
        key = frozenset({row['team1_id'], row['team2_id']})
        probabilities[key] = (row['team1_id'], row['team2_id'], row['proba_1'])
    return probabilities

def simulate_game(team1, team2, probabilities, team_name_mapping):
    key = frozenset({team1, team2})
    original_team1, original_team2, prob = probabilities[key]
    if original_team1 != team1:
        prob = 1 - prob
    winner = team1 if prob >= 0.5 else team2
    game_result = f"{team_name_mapping[team1]} ({team1}) vs {team_name_mapping[team2]} ({team2}): Winner is {team_name_mapping[winner]} ({winner})"
    return winner, game_result

def simulate_tournament(games, probabilities, team_name_mapping):
    regions = list(games.keys())
    sweet_sixteen_winners = []
    elite_eight_winners = []
    game_results = []
    
    # Region
    for region in regions:
        teams = games[region]
        while len(teams) > 1:
            winners = []
            for team1_id, team2_id in teams:
                winner, game_result = simulate_game(team1_id, team2_id, probabilities, team_name_mapping)
                winners.append(winner)
                game_results.append(game_result)
            teams = [(winners[i], winners[i+1]) for i in range(0, len(winners), 2)]
        sweet_sixteen_winners.append(winners)
    
    # Elite Eight
    for winners in sweet_sixteen_winners:
        winner, game_result = simulate_game(winners[0], winners[1], probabilities, team_name_mapping)
        elite_eight_winners.append(winner)
        game_results.append(game_result)
        
    # Final Four
    winner1, game_result = simulate_game(elite_eight_winners[0], elite_eight_winners[1], probabilities, team_name_mapping)
    game_results.append(game_result)
    winner2, game_result = simulate_game(elite_eight_winners[2], elite_eight_winners[3], probabilities, team_name_mapping)
    game_results.append(game_result)

    # Championship game
    champion, game_result = simulate_game(winner1, winner2, probabilities, team_name_mapping)
    game_results.append(game_result)

    return champion, game_results

def main():
    bracket_file = "March Madness Printable Mens Bracket.csv"
    #probabilities_file = "NCAA_Tourney_2023 - Logistic.xlsx"
    probabilities_file = "NCAA_Tourney_2023 - RF.xlsx"
    #probabilities_file = "NCAA_Tourney_2023 - LGBM.xlsx"

    bracket = read_bracket(filepath + bracket_file)
    probabilities = read_probabilities(filepath + probabilities_file)
    team_name_mapping = get_team_name_mapping(bracket_file)
    winner, game_results = simulate_tournament(bracket, probabilities, team_name_mapping)
    print(f"The winner of the tournament is: {team_name_mapping[winner]} ({winner})")
    print("\nGame Results:")
    for result in game_results:
        print(result)

if __name__ == "__main__":
    main()